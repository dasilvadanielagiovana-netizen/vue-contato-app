<script>
import Cabecalho from './components/icons/Cabecalho.vue'
import Contato from './components/Contato.vue'
import Rodape from './components/icons/Rodape.vue'

export default {
  components: { Cabecalho, Contato, Rodape },
  data() {
    return {
      contatos: [
        { id: 1, nome: 'Ana Silva', email: 'ana@example.com', foto: 'https://randomuser.me/api/portraits/women/1.jpg' },
        { id: 2, nome: 'Carlos Souza', email: 'carlos@example.com', foto: 'https://randomuser.me/api/portraits/men/1.jpg' },
        { id: 3, nome: 'Mariana Oliveira', email: 'mariana@example.com', foto: 'https://randomuser.me/api/portraits/women/2.jpg' },
        { id: 4, nome: 'Pedro Costa', email: 'pedro@example.com', foto: 'https://randomuser.me/api/portraits/men/2.jpg' }
      ]
    }
  },
  methods: {
    excluirContato(id) {
  console.log('Método excluirContato chamado com id:', id)
  if (confirm('Tem certeza que deseja excluir este contato?')) {
    this.contatos = this.contatos.filter(contato => contato.id !== id)
      }
    }
  }
}
</script>

<template>
  <div id="app">
    <Cabecalho titulo="Lista de Contatos" />
    <div class="contacts-container">
      <Contato
        v-for="contato in contatos"
        :key="contato.id"
        :id="contato.id"
        :nome="contato.nome"
        :email="contato.email"
        :foto="contato.foto"
        @excluir="excluirContato"
      />
    </div>
    <Rodape curso="Vue.js" instituicao="ETEC" />
  </div>
</template>



<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.contacts-container {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: 20px;
  margin: 20px 0;
}

header {
  background: linear-gradient(135deg, #3a3a5e, #4a4a7a);
  color: white;
  padding: 20px;
  text-align: center;
  border-radius: 10px;
  margin-bottom: 20px;
}

footer {
  background: #2c3e50;
  color: white;
  padding: 15px;
  text-align: center;
  border-radius: 10px;
  margin-top: 20px;
}
</style>