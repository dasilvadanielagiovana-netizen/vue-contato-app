<script>
export default {
  props: {
    id: Number,
    nome: String,
    email: String,
    foto: String
  }
}
</script>

<template>
  <div class="contact-card">
    <img :src="foto" :alt="nome" class="contact-photo">
    <div class="contact-info">
      <h3>{{ nome }}</h3>
      <p>{{ email }}</p>
    </div>
  <button class="remove-btn" @click="$emit('excluir', id)">Remover</button>
   </div>
</template>



<style scoped>
.contact-card {
  display: flex;
  align-items: center;
  padding: 15px;
  border: 1px solid #e0e0e0;
  border-radius: 8px;
  background: white;
  transition: all 0.3s ease;
}

.contact-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.contact-photo {
  width: 50px;
  height: 50px;
  border-radius: 50%;
  object-fit: cover;
  margin-right: 15px;
}

.contact-info {
  flex: 1;
}

.contact-info h3 {
  margin: 0;
  color: #2c3e50;
}

.contact-info p {
  margin: 5px 0 0;
  color: #7f8c8d;
  font-size: 0.9em;
}

.remove-btn {
  background: #ff6b6b;
  color: white;
  border: none;
  padding: 8px 15px;
  border-radius: 4px;
  cursor: pointer;
  transition:0.3s;
}

.remove-btn:hover {
  background: #ff5252;
}
</style>