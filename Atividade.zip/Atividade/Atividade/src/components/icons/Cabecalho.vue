 <script>
  export default {
    props: ['titulo']
  }
  </script> 
  
  <template>
    <header>
      <h1>{{ titulo }}</h1>
    </header>
  </template>
  
 