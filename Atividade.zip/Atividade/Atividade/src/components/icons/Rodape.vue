    <script>
  export default {
    props: ['curso', 'instituicao']
  }
  </script>
  <template>
    <footer>
      <p>Curso: {{ curso }}</p>
      <p>Instituição: {{ instituicao }}</p>
    </footer>
  </template>
  
